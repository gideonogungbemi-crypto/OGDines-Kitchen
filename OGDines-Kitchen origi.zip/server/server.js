// Basic Node.js placeholder
console.log("OGDines Kitchen Server Running...");