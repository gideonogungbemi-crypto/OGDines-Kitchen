import React from 'react';
import Menu from './components/Menu';
import OrderForm from './components/OrderForm';
import OrderTracking from './components/OrderTracking';
import AdminDashboard from './components/AdminDashboard';

function App() {
  return (
    <div>
      <h1>OGDines Kitchen</h1>
      <Menu />
      <OrderForm />
      <OrderTracking />
      <AdminDashboard />
    </div>
  );
}

export default App;
