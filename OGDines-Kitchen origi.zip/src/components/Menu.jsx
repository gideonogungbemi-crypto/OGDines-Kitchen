import React from 'react';

function Menu() {
  return (
    <div>
      <h2>Menu</h2>
      <ul>
        <li>Jollof Rice - ₦1500</li>
        <li>Amala with Gbegiri - ₦1000</li>
        <li>Pounded Yam & Egusi - ₦1800</li>
      </ul>
    </div>
  );
}

export default Menu;
