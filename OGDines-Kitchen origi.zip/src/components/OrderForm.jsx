import React from 'react';

function OrderForm() {
  return (
    <div>
      <h2>Place an Order</h2>
      <form>
        <input type="text" placeholder="Enter meal" />
        <input type="text" placeholder="Your name" />
        <button type="submit">Order Now</button>
      </form>
    </div>
  );
}

export default OrderForm;
