import React from 'react';

function OrderTracking() {
  return (
    <div>
      <h2>Track Your Order</h2>
      <p>Status: Preparing...</p>
    </div>
  );
}

export default OrderTracking;
