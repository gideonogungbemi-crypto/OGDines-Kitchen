# OGDines Kitchen
A simple food ordering web app.